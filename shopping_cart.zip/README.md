# shopping_cart
Steps to run the application

1. Store the project into nodejs folder

2. Goto project folder and run the below command if express is not installed:
    npm install -g express
 
3. Goto projetc folder and run server.js in cmd prompt using the below command:
     node server.js

4. Once the server is running, open the browser:
     http://localhost:3000/cart/
	 
	 
In this The below tasks are done:
1. Created the HTML Template
2. Opened the popup on Edit button click
3. Integrated the Promotional Code Coupon. Promotional code will succeed on "JF10"
4. Calculated the total amount on Qty * Price
5. Calculated the Subtotal and  Estimated Total